class CustomError extends Error {                   //Create class with name CustomError, which will extend off the built in error 
    constructor(args){                              //constructor makes an object 
    super(args);                                    //
    this.name = 'CustomError'                       //creates the class name property "CustomError"

    }
}



function throwGenericError(){
throw new Error("Generic Error")                    //throw new 
};

function throwCustomError(){
    throw new CustomError("Custom Error")
}

//Generic

console.log("Force generic error");



try{
    console.log("Generic error try block");
    throwGenericError();
} catch(err) {
    console.log("Generic error catch block");
    console.log(`${err.name}: ${err.message}`);
} finally {
    console.log("Generic error finally block"); 
}

//Custom 

console.log("Force custom error");

try{
    console.log("Custom error try block");
    throwCustomError();
} catch(err) {
    console.log("Custom error catch block");
    console.log(`${err.name}: ${err.message}`);
} finally {
    console.log("Custom error finally block"); 
}